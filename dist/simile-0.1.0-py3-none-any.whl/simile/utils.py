# simile/utils.py
"""
Optional helper functions. You might or might not need this, depending on how you structure your code.
For now, it's just a placeholder.
"""

def example_helper():
    pass
